package fise2.image4.projetinfo;

import java.io.IOException;
import static java.lang.Integer.max;
import java.util.ArrayList;
import javafx.util.Duration;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.shape.Rectangle;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.image.WritableImage;
import javafx.scene.text.Text;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.highgui.HighGui;
import org.opencv.videoio.VideoCapture;

public class SecondaryController {

    @FXML
    private ImageView cameraView;
    @FXML
    private Label redScoreLabel;
    @FXML
    private Label blueScoreLabel;
    @FXML
    private Label teamTurnLabel;
    @FXML
    private Label elapsedTimeLabel;
    @FXML
    private Label redTurnsLabel;
    @FXML
    private Label blueTurnsLabel;
    @FXML 
    private Button pauseButton;
    @FXML
    private Rectangle dimOverlay;
    @FXML
    private Rectangle launchAreaSetOverlay;
    @FXML
    private Text gamePausedLabel;
    @FXML
    private Text launchAreaSetLabel;
    @FXML 
    private Label avantage;
    @FXML
    private Label fpsLabel;
    @FXML
    private Text targetSetLabel;


    private Timeline elapsedTimeTimeline;
    private int elapsedSeconds;
    private boolean isPaused = false;
    private boolean isCalibrationSet = false;
    private boolean isLaunchAreaSet = false;
    private boolean isTargetSet = false;
    private double launchAreaXPosition = 0;
    private double launchAreaYPosition = 0;
    private List<Point> launchAreaPositions = new ArrayList<>();
    private Point targetPosition = new Point(0,0);


    private VideoCapture capture;
    private Timer frameTimer;
    private GameManager gameEngine;
    private TokenDetectorbis tkd;
    private long lastFpsCheck = 0;
    private int currentFPS = 0;
    private int totalFrames = 0;
    
    // EN PLUS
    private List<Point> centers;
    private boolean state;
    // FIN EN PLUS

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary");
    }

    public void initialize() {
        // Load OpenCV native library
        System.load("C:/Users/KazuWaii/eclipse-workspace/image4_project/src/main/resources/libs/opencv_java4100.dll");

        // Initialize the video capture
        capture = new VideoCapture(0);
        // EN PLUS
        centers = new ArrayList<Point>();
        state = true; 
        // FIN EN PLUS

        if (!capture.isOpened()) {
            System.out.println("Error: Unable to open video stream.");
            return;
        }

        // Initialize game manager and token detector
        Mat frame = captureFrame();
        if (!frame.empty()) {
            // gameEngine = new GameManager(generateTarget(frame), new Point(500,300)); // EN PLUS
            gameEngine = new GameManager(new Point(500,300),frame);
            Mat background = frame.clone();
            tkd = new TokenDetectorbis(background, List.of(0, 40));
        } else {
            System.out.println("Error: Unable to initialize background.");
            return;
        }

        startElapsedTime(); // Start tracking elapsed time
        
        // Start frame update timer
        cameraView.setOnMouseClicked(event -> {
            //handleLaunchAreaSet(event.getX()/0.8, event.getY()/0.8);
                    
            launchAreaPositions.add(new Point(event.getX()/0.8, event.getY()/0.8));  
            
            if(launchAreaPositions.size() == 2) {
                isLaunchAreaSet = true;
                //handleLaunchAreaSet(launchAreaPositions);
                gameEngine.setLaunchAreaPositions(launchAreaPositions);
            }
            
            if(launchAreaPositions.size() == 3 && 
                event.getX()/0.8 >= Math.min(launchAreaPositions.get(0).x,launchAreaPositions.get(1).x) && 
                 event.getX()/0.8 <= Math.max(launchAreaPositions.get(0).x,launchAreaPositions.get(1).x) &&
                  event.getY()/0.8 >= Math.min(launchAreaPositions.get(0).y,launchAreaPositions.get(1).y) && 
                 event.getY()/0.8 <= Math.max(launchAreaPositions.get(0).y,launchAreaPositions.get(1).y))
                  {
                      launchAreaPositions.remove(2);
            }
                        
            if(launchAreaPositions.size() == 3) {
                //targetPosition = launchAreaPositions.get(2);
                gameEngine.setTarget(launchAreaPositions.get(2));
                isTargetSet = true;
            }
        });
        startFrameTimer();
        applyRoundedCornersToCameraView();
        

        
        gameEngine.setOnScoreUpdate(() -> Platform.runLater(this::updateScoresUI));
    }
    
    private void handleLaunchAreaSet(List<Point> launchAreaPositions) {
        System.out.println(launchAreaPositions);
        //gameEngine.setLaunchAreaPositions(launchAreaPositions);
        
        
    }
    
    // EN PLUS
    private Double dist(Point A, Point B){
    	
    	return Math.sqrt(Math.pow(A.x - B.x, 2) + Math.pow(A.y - B.y, 2));
    }
    
    public boolean isStable(List<Point> rayons, double threshold) {
        if (rayons.size() < 20) {
            return false; 
        }
        
        double sum = 0.0;
        for (int i = rayons.size() - 20; i < rayons.size() - 1; i++) {
            double distance = dist(rayons.get(i), rayons.get(i + 1));
            if (distance > threshold) {
                return false; 
            }
            sum += distance;
        }
        
        double normalizedSum = sum / 20.0;
        return normalizedSum < threshold;
    }
    /*
    public Point generateTarget(Mat frame) {
        
        int width = frame.cols() ;
        int height = frame.rows() ;
        Random random = new Random() ;
        
        // Define the mean (center of the image)
        double meanX = width / 2.0;
        double meanY = height / 2.0;

        // Define the standard deviation (spread of the points)
        double stdDevX = width / 6.0; // Smaller value concentrates points near the center
        double stdDevY = height / 6.0;

        // Generate Gaussian-distributed random values
        double x = Math.max(0, Math.min(width - 1, random.nextGaussian() * stdDevX + meanX));
        double y = Math.max(0, Math.min(height - 1, random.nextGaussian() * stdDevY + meanY));

        return new Point(x, y);
    }
    // FIN EN PLUS
    */
    public void updateUI() {
        // Update the UI with the remaining turns for each team
        redTurnsLabel.setText(String.valueOf(gameEngine.getTurnsRemainingRED()));
        blueTurnsLabel.setText(String.valueOf(gameEngine.getTurnsRemainingBLUE()));
        avantage.setText("AVANTAGE : " + String.valueOf(Math.abs(gameEngine.getAvLive())));
        if(gameEngine.getAvLive() < 0) {
            avantage.setStyle("-fx-text-fill: #ff0000; -fx-font-size: 20px; -fx-font-family: 'Immortal', sans-serif;");
        } else {
            avantage.setStyle("-fx-text-fill: #0006ff; -fx-font-size: 20px; -fx-font-family: 'Immortal', sans-serif;");
        }
    }
    
    public void handleTurnMade(boolean isRedTeam) {
        // Example: if it's red team's turn
        gameEngine.setTurnsRemaining(isRedTeam);  // Red team turn
        updateUI();  // Refresh the UI to show the updated remaining turns
    }
    
    private void startElapsedTime() {
        elapsedSeconds = 0;

        // Create a Timeline to update the elapsed time every second
        elapsedTimeTimeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            elapsedSeconds++;
            updateElapsedTimeLabel();
        }));

        elapsedTimeTimeline.setCycleCount(Timeline.INDEFINITE); // Run indefinitely
        elapsedTimeTimeline.play();
    }

    private void updateElapsedTimeLabel() {
        int minutes = elapsedSeconds / 60;
        int seconds = elapsedSeconds % 60;
        elapsedTimeLabel.setText(String.format("%02d:%02d", minutes, seconds));
    }

    public void resetElapsedTime() {
        elapsedTimeTimeline.stop();
        elapsedSeconds = 0;
        updateElapsedTimeLabel();
        elapsedTimeTimeline.play();
    }

    public void pauseElapsedTime() {
        elapsedTimeTimeline.pause();
    }

    public void resumeElapsedTime() {
        elapsedTimeTimeline.play();
    }
    
    
    private Mat captureFrame() {
        Mat frame = new Mat();
        lastFpsCheck = System.nanoTime();
        totalFrames = 0;
        currentFPS = 0;
        if (capture.isOpened()) {
            capture.read(frame);
            totalFrames++;
        }
        showFPS();

        return frame;
    }

    private void startFrameTimer() {
        frameTimer = new Timer(true);
        frameTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Mat frame = captureFrame();
                if (!frame.empty()) {
                    //Gestion du jeu sans touches
                    updateFrame(frame);
                    if(isTargetSet && isLaunchAreaSet && !isPaused) {

                    Circle circle = tkd.detectToken(frame);
                    // EN PLUS
                    if(!isCalibrationSet) {
                        System.out.println("STARTING CALIBRATION, PLEASE PLACE TOKEN IN LAUNCH AREA");
                        while(!isPaused){
                            if (gameEngine.isCircleInLaunchArea(circle, launchAreaPositions)){
                                tkd.fixRadius(frame.clone());
                                System.out.println("CALIBRATION SUCCESSFULL");
                                break;
                            } else {
                                //System.out.println("CALIBRATION UNSUCCESSFULL");
                                totalFrames++;
                                showFPS();
                            }
                            updateFrame(frame);
                            circle = tkd.detectToken(frame);
                            totalFrames++;
                            showFPS();
                        }
                        isCalibrationSet = !isCalibrationSet;
                    }
                    
                    
                    // Création de la frame à afficher
                    Mat displayFrame = frame.clone();

                    Point c = tkd.detectTokenWithCanny(displayFrame);
                    if(c != null) {
                        System.out.println("Pas null");
                        centers.add(c);
                    }


                    if (isStable(centers, 50) != state ) {
                        state = !state;
                        if (state) {
                                System.out.println("stable");

                        } else {
                                System.out.println("mooved");

                        }

                    }

                    //tkd.displayCircles(displayFrame, gameEngine.getCenters(), gameEngine.getRadius(), gameEngine.getTeamid());
                    // tkd.displayHud(displayFrame, gameEngine.scoreGameBLUE, gameEngine.scoreGameRED, gameEngine.avLive);
                    //tkd.displayTarget(displayFrame, gameEngine.getTarget());
                    //tkd.displayLaunchArea(displayFrame, gameEngine.getLaunchArea());
                    // FIN EN PLUS
                    
                    
                    while (!gameEngine.isCircleInLaunchArea(circle, launchAreaPositions) && !isPaused) {
                        updateFrame(frame);
                        circle = tkd.detectToken(frame);
                        totalFrames++;
                        showFPS();
                    }
                    System.out.println("IN LAUNCH AREA");
            
                    while (!gameEngine.isCircleOutLaunchArea(circle, launchAreaPositions) && !isPaused) {
                        updateFrame(frame);
                        circle = tkd.detectToken(frame);
                        totalFrames++;
                        showFPS();
                    }
                    
                    long startTime = System.currentTimeMillis();
                    
                    while ((System.currentTimeMillis()-startTime < 3000) && !isPaused){
                        updateFrame(frame);
                        totalFrames++;
                        showFPS();
                    }
                    circle = tkd.detectToken(frame);
                    /*
                    if (!gameEngine.isCircleInLaunchArea(circle)){
                        gameEngine.addCircle(circle.getCenter(), circle.getRadius());
                        centers.clear();
                        System.out.println("LAUNCHED");
                    }*/
                    if ((gameEngine.isCircleOutLaunchArea(circle, launchAreaPositions)) && (circle!=null)){
                        gameEngine.addCircle(circle.getCenter(), circle.getRadius());
                        centers.clear();
                        System.out.println("LAUNCHED");
                    }

                    // Convert Mat to WritableImage
                    WritableImage writableImage = OpenCVUtils.matToImage(frame.clone());

                    // Update the ImageView on the JavaFX Application Thread
                    Platform.runLater(() -> {
                        cameraView.setImage(writableImage);
                        updateTurnsRemaining();
                        updateTurnUI();  // Update current team                     
                        updateScoresUI(); // Update UI safely
                        
                        resetTurnsRemaining();
                        
                       // fpsLabel.setText(String.format("FPS: %.1f", fps));
                        
                        //updateUI();
                    });                    
                    // Update game logic
                    gameEngine.update();
                    }
                }
            }
        }, 0, 33); // ~30 FPS
    }
    
    // EN PLUS
    private void updateFrame(Mat frame){
        totalFrames++;
        
        if (!capture.read(frame)) {
                    System.out.println("Error: Could not read frame from stream.");
        }
        
        Mat displayFrame = frame.clone();
              
        tkd.displayCircles(displayFrame, gameEngine.getCenters(), gameEngine.getRadius(), gameEngine.getTeamid());
        //tkd.displayHud(displayFrame, gameEngine.scoreGameBLUE, gameEngine.scoreGameRED, gameEngine.avLive);
        
        //tkd.displayLaunchArea(displayFrame, gameEngine.getLaunchArea());
        if(isLaunchAreaSet && !isTargetSet) {
            tkd.displayLaunchArea(displayFrame, gameEngine.getLaunchAreaPositions());
            //tkd.displayTarget(displayFrame, gameEngine.getTarget());
            WritableImage writableImage = OpenCVUtils.matToImage(displayFrame);
            Platform.runLater(() -> cameraView.setImage(writableImage));
            while(!isTargetSet) {
                targetSetLabel.setVisible(true);
            } 
            targetSetLabel.setVisible(false);
            launchAreaSetOverlay.setVisible(false);
            }
        if(isLaunchAreaSet && isTargetSet) {
            tkd.displayLaunchArea(displayFrame, gameEngine.getLaunchAreaPositions());
            tkd.displayTarget(displayFrame, gameEngine.getTarget());
        }
        
        WritableImage writableImage = OpenCVUtils.matToImage(displayFrame);
        Platform.runLater(() -> cameraView.setImage(writableImage));
        while(!isLaunchAreaSet) {
            launchAreaSetOverlay.setVisible(true);
            launchAreaSetLabel.setVisible(true);
        } 
        launchAreaSetLabel.setVisible(false);
        
        
        
        // Update the ImageView on the JavaFX Application Thread
        /*Platform.runLater(() -> {
            cameraView.setImage(writableImage);
            cameraView.setImage(writableImage);
        }); */
    }
    // FIN EN PLUS
    private void showFPS() {
        if (System.nanoTime() - lastFpsCheck >= 1000000000) { // 1 second interval
            currentFPS = totalFrames;
            totalFrames = 0; // Reset frame count for the next second
            lastFpsCheck = System.nanoTime();
            //System.out.println("FPS: "+ currentFPS);
            Platform.runLater(() -> fpsLabel.setText(String.format("FPS: %d", currentFPS)));
        }
    }
    private void resetTurnsRemaining(){
        if (gameEngine.getTurnCounts() == 16 || gameEngine.getTurnCounts() == 0) {
            gameEngine.setTurnsRemainingRED(8);
            gameEngine.setTurnsRemainingBLUE(8);
       }
    }
    
    private void updateTurnsRemaining() {
        if (gameEngine.getCurrentTeam().equals("Red Team")) handleTurnMade(false);
        else handleTurnMade(true);
    }
    
    private void updateScoresUI() {
        redScoreLabel.setText(String.valueOf(gameEngine.scoreGameRED));
        blueScoreLabel.setText(String.valueOf(gameEngine.scoreGameBLUE));
    }
    private void updateTurnUI() {
        String currentTeam = gameEngine.getCurrentTeam();
        teamTurnLabel.setText(currentTeam);

        // Change the label color based on the team
        if (currentTeam.equals("Red Team")) {
            teamTurnLabel.setStyle("-fx-text-fill: #ff0000; -fx-font-size: 30px; -fx-font-family: 'Immortal', sans-serif;");
        } else if (currentTeam.equals("Blue Team")) {
            teamTurnLabel.setStyle("-fx-text-fill: #0006ff; -fx-font-size: 30px; -fx-font-family: 'Immortal', sans-serif;");
        }
    }

    

    // Handle key presses
    private void handleKeyPress(KeyEvent event) {
        char pressedKey = event.getText().toLowerCase().charAt(0);

        System.out.println("Key pressed: " + pressedKey);

        switch (pressedKey) {
            case 'f':
                // Set background
                Mat frame = captureFrame();
                tkd.setBackground(frame.clone());
                break;
            case 't':
                // Detect token
                Mat frameForToken = captureFrame();
                Circle circle = tkd.detectToken(frameForToken);
                if (circle != null) {
                    if (gameEngine.getCurrentTeam().equals("Red Team")) handleTurnMade(true);
                    else handleTurnMade(false);
                    gameEngine.addCircle(circle.getCenter(), circle.getRadius());
                }
                break;
            case 'p':
                // Pause/Resume game
                togglePause();
                break;
            case 'q':
                // Quit the application
                stopCamera();
                Platform.exit();
                break;
            default:
                break;
        }
    }
    
    @FXML
    private void togglePause() {
        if (isPaused) {
            resumeGame();
        } else {
            pauseGame();
        }
        isPaused = !isPaused;
    }
    
    private void pauseGame() {
        // Stop timers
        pauseElapsedTime();

        
        // Stop frame capture timer
        frameTimer.cancel();
        
        frameTimer = null; // Ensure it's set to null so we can recreate it on resume
 
        System.out.println(frameTimer);
        // Disable all interactions except for the 'p' key
        cameraView.setDisable(true);
        //pauseButton.setDisable(false);
        /*Platform.runLater(() -> {
            if (cameraView.getScene() != null) {
                cameraView.getScene().setOnKeyPressed(event -> {
                    if ("p".equalsIgnoreCase(event.getText())) {
                        togglePause(); // Allow toggling pause using 'p'
                    }
                });
            }
        });*/
        pauseButton.setStyle("-fx-background-color: #FF5555; -fx-background-radius: 155; -fx-font-family:  'Immortal', sans-serif; -fx-font-size: 20");
        // Show dim overlay to darken other UI elements
        dimOverlay.setVisible(true);
        gamePausedLabel.setVisible(true);
        
        System.out.println("Game paused.");
    }

    
    private void resumeGame() {
        // Restart timers
        resumeElapsedTime();
        startFrameTimer();

        // Re-enable interactions
        cameraView.setDisable(false);
        /*Platform.runLater(() -> {
            if (cameraView.getScene() != null) {
                cameraView.getScene().setOnKeyPressed(this::handleKeyPress); // Reattach key listener
            }
        }); */
        pauseButton.setStyle("-fx-background-color: #6fdbff; -fx-background-radius: 155; -fx-font-family:  'Immortal', sans-serif; -fx-font-size: 20");
        // Show dim overlay to darken other UI elements
        dimOverlay.setVisible(false);
        gamePausedLabel.setVisible(false);

        System.out.println("Game resumed.");
    }

    
    public void stopCamera() {
        if (frameTimer != null) {
            frameTimer.cancel();
        }
        if (capture != null) {
            capture.release();
        }
    }
    
    private void applyRoundedCornersToCameraView() {
        // Define the width, height, and corner radius
        double cornerRadius = 20; // Adjust the radius as needed
        double width = cameraView.getFitWidth();
        double height = cameraView.getFitHeight();

        // Create a Rectangle to clip the ImageView with rounded corners
        Rectangle clip = new Rectangle(0, 0, width, height);
        clip.setArcWidth(cornerRadius);
        clip.setArcHeight(cornerRadius);

        // Clip the cameraView with the rectangle
        cameraView.setClip(clip);

        // Optional: Set the width and height of the ImageView (you can adjust this)
        cameraView.setFitWidth(width);
        cameraView.setFitHeight(height);
    }
}
