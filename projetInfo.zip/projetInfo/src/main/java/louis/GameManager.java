/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testopenCV;

import org.opencv.core.Point;
import org.opencv.core.Mat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Random;


public class GameManager {

    public int scoreGameRED;
    public int scoreGameBLUE;
    public int avLive ;
    

    private Point target;
    private Point launchArea;

    private final List<Point> centers;
    private final List<Integer> radius;
    private final List<Boolean> teamid;
    private int turnCounts;
    
    // Constructeurs
    public GameManager() {
        this.target = new Point(100, 100);
        this.launchArea = new Point(200, 200);
        this.centers = Collections.synchronizedList(new ArrayList<>());
        this.radius = Collections.synchronizedList(new ArrayList<>());
        this.teamid = Collections.synchronizedList(new ArrayList<>());
        this.scoreGameRED = 0;
        this.scoreGameBLUE = 0;
        turnCounts = 0;
    }

    public GameManager(Point initialLaunchArea) {
        this.target = new Point(100, 100);
        this.launchArea = initialLaunchArea;
        this.centers = Collections.synchronizedList(new ArrayList<>());
        this.radius = Collections.synchronizedList(new ArrayList<>());
        this.teamid = Collections.synchronizedList(new ArrayList<>());
        this.scoreGameRED = 0;
        this.scoreGameBLUE = 0;
        turnCounts = 0;
    }
    
    public GameManager(Point initialLaunchArea, Mat frame) {
        this.launchArea = initialLaunchArea;
        this.target = generateTarget(frame);
        this.centers = Collections.synchronizedList(new ArrayList<>());
        this.radius = Collections.synchronizedList(new ArrayList<>());
        this.teamid = Collections.synchronizedList(new ArrayList<>());
        this.scoreGameRED = 0;
        this.scoreGameBLUE = 0;
        turnCounts = 0;
    }

    // Gestion des chevauchements
    private int circlesOverlapping(Point center, Integer radius) {
        for (int i = 0; i < centers.size(); i++) {
            if (twoCirclesOverlapping(center, radius, this.centers.get(i), this.radius.get(i))) {
                return i;
            }
        }
        return -1;
    }

    private boolean twoCirclesOverlapping(Point newCenter, Integer newRadius, Point center, Integer radius) {
        if (newRadius == 0 || radius == 0) return false;
        
        double dist = Math.sqrt(Math.pow(newCenter.x - center.x, 2) + Math.pow(newCenter.y - center.y, 2));
        if (dist >= newRadius + radius) return false;
        
        double A_newCircle = Math.PI * Math.pow(newRadius, 2);
        double t1 = Math.acos((Math.pow(dist, 2) + Math.pow(newRadius, 2) - Math.pow(radius, 2)) / (2 * dist * newRadius));
        double t2 = Math.acos((Math.pow(dist, 2) + Math.pow(radius, 2) - Math.pow(newRadius, 2)) / (2 * dist * radius));
        double t3 = (radius + newRadius - dist) * (dist + newRadius - radius) * (dist - newRadius + radius) * (dist + newRadius + radius);
        t3 = Math.sqrt(t3) / 2;

        double A_intersection = (Math.pow(newRadius, 2) * t1) + (Math.pow(radius, 2) * t2) - t3;
        return A_intersection > 0.05 * A_newCircle;
    }
    
    // Calcul de la distance entre deux points
    private Double dist(Point A, Point B){
    	
    	return Math.sqrt(Math.pow(A.x - B.x, 2) + Math.pow(A.y - B.y, 2));
    }
    
    // Suppression d'un cercle
    public void removeCircle(int i) {
        centers.remove(i);
        radius.remove(i);
        teamid.remove(i);
    }

    // Ajout d'un cercle
    public void addCircle(Point newCenter, Integer newRadius) {
        int v = circlesOverlapping(newCenter, newRadius);
        if (v >= 0) {
            removeCircle(v);
        }
        centers.add(newCenter);
        radius.add(newRadius);
        teamid.add(turnCounts % 2 == 0);
        winnerLive();
        turnCounts++;
    } 
    
    public Point generateTarget(Mat frame) {
        
        int width = frame.cols() ;
        int height = frame.rows() ;
        Random random = new Random() ;
        
        // Define the mean (center of the image)
        double meanX;
        double meanY;
        
        if (this.launchArea.x > width/2){
            meanX = width/4.0;
            if (this.launchArea.y > height/2){
                meanY = height/4.0;
            }
            else{
                meanY = 3*height/4.0;
            }
        }
        else{
            meanX = 3*width/4.0;
            if (this.launchArea.y > height/2){
                meanY = height/4.0;
            }
            else{
                meanY = 3*height/4.0;
            }
        }

        // Define the standard deviation (spread of the points)
        double stdDevX = width / 10.0; // Smaller value concentrates points near the center
        double stdDevY = height / 10.0;

        // Generate Gaussian-distributed random values
        double x = Math.max(0, Math.min(width - 1, random.nextGaussian() * stdDevX + meanX));
        double y = Math.max(0, Math.min(height - 1, random.nextGaussian() * stdDevY + meanY));

        return new Point(x, y);
    }
    
    public boolean isCircleInLaunchArea(Circle token){
        if (token != null){
            Point center = token.getCenter();
            int radius = token.getRadius();
            return ((center.x + radius) <= (launchArea.x + 100))
                    && ((center.x - radius) >= (launchArea.x - 100))
                    && ((center.y + radius) <= (launchArea.y + 100))
                    && ((center.y - radius) >= (launchArea.y - 100));
        }
        else return false;
    }
    
    // Score Live
    public void winnerLive() {
        if (centers.isEmpty()) {
            throw new IllegalStateException("Normalement impossible de voir ce message");
        }
        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < centers.size(); i++) {
            indices.add(i);
        }
        indices.sort((i1, i2) -> Double.compare(
            dist(centers.get(i1), target), 
            dist(centers.get(i2), target)
        ));
        int c = 1; 
        boolean currentTeam = teamid.get(indices.get(0)); 
        
        for (int i = 1; i < indices.size(); i++) {
            if (teamid.get(indices.get(i)) == currentTeam) {
                c++;
            } else {
                break;
            }
        }
        avLive = currentTeam ? c : -c; 
    }

    

    // Passage à la partie suivante
    public void update() {
        if (turnCounts == 6) {
        	turnCounts = 0;
        	if(avLive < 0) {
        		scoreGameRED -= avLive;
        	} else {
        		scoreGameBLUE += avLive;
        	}
            avLive = 0 ;    
        	centers.clear();
        	radius.clear();
        	teamid.clear();
        }
    }
    
    
    // Getters Setters
    public List<Point> getCenters() {
        return new ArrayList<>(centers);
    }

    public List<Integer> getRadius() {
        return new ArrayList<>(radius);
    }

    public List<Boolean> getTeamid() {
        return new ArrayList<>(teamid);
    }

    public void setTarget(Point target) {
        this.target = target;
    }

    public Point getTarget() {
        return target;
    }
    
    public void setLaunchArea(Point launchArea) {
        this.launchArea = launchArea;
    }

    public Point getLaunchArea() {
        return launchArea;
    }
}
