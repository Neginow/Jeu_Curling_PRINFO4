package fise2.image4.projetinfo;

import static java.lang.Integer.max;
import org.opencv.core.Point;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import javafx.fxml.FXML;
import org.opencv.core.Mat;


public class GameManager {
    
    public int scoreGameRED;
    public int scoreGameBLUE;
    // EN PLUS
    public int avLive ;
    private Point launchArea;
    // FIN EN PLUS
    public int turnsRemainingRED=8;
    public int turnsRemainingBLUE=8;

    private Point target;
    private Runnable onScoreUpdate;
    
    private final List<Point> centers;
    private final List<Integer> radius;
    private final List<Boolean> teamid;
    private int turnCounts;
    
    
    public GameManager() {
        // EN PLUS
        this.launchArea = new Point(0, 0);
        // FIN EN PLUS
        this.target = new Point(0, 0);
        this.centers = Collections.synchronizedList(new ArrayList<>());
        this.radius = Collections.synchronizedList(new ArrayList<>());
        this.teamid = Collections.synchronizedList(new ArrayList<>());
        this.scoreGameRED = 0;
        this.scoreGameBLUE = 0;
        turnCounts = 0;
    }
    /*
    public GameManager(Point initialTarget) {
        // EN PLUS
        this.launchArea = new Point(0, 0);
        // FIN EN PLUS
        this.target = initialTarget;
        this.centers = Collections.synchronizedList(new ArrayList<>());
        this.radius = Collections.synchronizedList(new ArrayList<>());
        this.teamid = Collections.synchronizedList(new ArrayList<>());
        this.scoreGameRED = 0;
        this.scoreGameBLUE = 0;
        turnCounts = 0;
    }
    
    // EN PLUS
    public GameManager(Point initialTarget, Point initialLaunchArea) {
        this.target = initialTarget;
        this.launchArea = initialLaunchArea;
        this.centers = Collections.synchronizedList(new ArrayList<>());
        this.radius = Collections.synchronizedList(new ArrayList<>());
        this.teamid = Collections.synchronizedList(new ArrayList<>());
        this.scoreGameRED = 0;
        this.scoreGameBLUE = 0;
        turnCounts = 0;
    }
    // FIN EN PLUS
    */
    
    public GameManager(Point initialLaunchArea) {
        this.target = new Point(100, 100);
        this.launchArea = initialLaunchArea;
        this.centers = Collections.synchronizedList(new ArrayList<>());
        this.radius = Collections.synchronizedList(new ArrayList<>());
        this.teamid = Collections.synchronizedList(new ArrayList<>());
        this.scoreGameRED = 0;
        this.scoreGameBLUE = 0;
        turnCounts = 0;
    }
    
    public GameManager(Point initialLaunchArea, Mat frame) {
        this.launchArea = initialLaunchArea;
        this.target = generateTarget(frame);
        this.centers = Collections.synchronizedList(new ArrayList<>());
        this.radius = Collections.synchronizedList(new ArrayList<>());
        this.teamid = Collections.synchronizedList(new ArrayList<>());
        this.scoreGameRED = 0;
        this.scoreGameBLUE = 0;
        turnCounts = 0;
    }
    public void setTurnsRemaining(boolean isRedTeam) {
        if(isRedTeam) turnsRemainingRED = turnsRemainingRED-1;
        else turnsRemainingBLUE = turnsRemainingBLUE-1;
    }
    
    public void setTurnsRemainingRED(int v) {
        turnsRemainingRED = v;
    }

    public void setTurnsRemainingBLUE(int v) {
        turnsRemainingBLUE = v;
    }
    
    public int getTurnsRemainingRED() {
        return turnsRemainingRED;
    }

    public int getTurnsRemainingBLUE() {
        return turnsRemainingBLUE;
    }

    
    public void setOnScoreUpdate(Runnable callback) {
        this.onScoreUpdate = callback;
    }


    private int circlesOverlapping(Point center, Integer radius) {
        for (int i = 0; i < centers.size(); i++) {
            if (twoCirclesOverlapping(center, radius, this.centers.get(i), this.radius.get(i))) {
                return i;
            }
        }
        return -1;
    }

    private boolean twoCirclesOverlapping(Point newCenter, Integer newRadius, Point center, Integer radius) {
        if (newRadius == 0 || radius == 0) return false;
        
        double dist = Math.sqrt(Math.pow(newCenter.x - center.x, 2) + Math.pow(newCenter.y - center.y, 2));
        if (dist >= newRadius + radius) return false;
        
        double A_newCircle = Math.PI * Math.pow(newRadius, 2);
        double t1 = Math.acos((Math.pow(dist, 2) + Math.pow(newRadius, 2) - Math.pow(radius, 2)) / (2 * dist * newRadius));
        double t2 = Math.acos((Math.pow(dist, 2) + Math.pow(radius, 2) - Math.pow(newRadius, 2)) / (2 * dist * radius));
        double t3 = (radius + newRadius - dist) * (dist + newRadius - radius) * (dist - newRadius + radius) * (dist + newRadius + radius);
        t3 = Math.sqrt(t3) / 2;

        double A_intersection = (Math.pow(newRadius, 2) * t1) + (Math.pow(radius, 2) * t2) - t3;
        return A_intersection > 0.05 * A_newCircle;
    }
    private Double dist(Point A, Point B){
    	
    	return Math.sqrt(Math.pow(A.x - B.x, 2) + Math.pow(A.y - B.y, 2));
    }
    public void removeCircle(int i) {
        centers.remove(i);
        radius.remove(i);
        teamid.remove(i);
    }
    /*
    public void addCircle(Point newCenter, Integer newRadius) {
        int v = circlesOverlapping(newCenter, newRadius);
        if (v >= 0) {
            removeCircle(v);
        }
        centers.add(newCenter);
        radius.add(newRadius);
        teamid.add(turnCounts % 2 == 0);
        turnCounts++;
    } */
    
    // Ajout d'un cercle
    public void addCircle(Point newCenter, Integer newRadius) {
        int v = circlesOverlapping(newCenter, newRadius);
        if (v >= 0) {
            removeCircle(v);
        }
        centers.add(newCenter);
        radius.add(newRadius);
        teamid.add(turnCounts % 2 == 0);
        winnerLive();
        turnCounts++;
    } 
    
    // EN PLUS
    private Point generateTarget(Mat frame) {
        
        int width = frame.cols() ;
        int height = frame.rows() ;
        Random random = new Random() ;
        
        // Define the mean (center of the image)
        double meanX;
        double meanY;
        
        if (this.launchArea.x > width/2){
            meanX = width/4.0;
            if (this.launchArea.y > height/2){
                meanY = height/4.0;
            }
            else{
                meanY = 3*height/4.0;
            }
        }
        else{
            meanX = 3*width/4.0;
            if (this.launchArea.y > height/2){
                meanY = height/4.0;
            }
            else{
                meanY = 3*height/4.0;
            }
        }

        // Define the standard deviation (spread of the points)
        double stdDevX = width / 10.0; // Smaller value concentrates points near the center
        double stdDevY = height / 10.0;

        // Generate Gaussian-distributed random values
        double x = Math.max(0, Math.min(width - 1, random.nextGaussian() * stdDevX + meanX));
        double y = Math.max(0, Math.min(height - 1, random.nextGaussian() * stdDevY + meanY));

        return new Point(x, y);
    }
    // FIN EN PLUS
    
    public boolean getWinner() {
        if (centers.isEmpty()) {
            throw new IllegalStateException("Normalement impossible de voir ce message");
        }

        int minIndex = 0; 
        double minDistance = 1000000;
        for (int i = 1; i < centers.size(); i++) {
            double distance = dist(centers.get(i), target);
            if (distance < minDistance) {
                minDistance = distance;
                minIndex = i;
            }
        }

        return teamid.get(minIndex); 
    }
    
    // EN PLUS
    /*public boolean isCircleInLaunchArea(Circle token){
        Point center = token.getCenter();
        int radius = token.getRadius();
        return ((center.x + radius) <= (launchArea.x + 75))
                && ((center.x - radius) >= (launchArea.x - 75))
                && ((center.y + radius) <= (launchArea.y + 75))
                && ((center.y - radius) >= (launchArea.y - 75));
    }
    */
    public boolean isCircleInLaunchArea(Circle token){
        if (token != null){
            Point center = token.getCenter();
            int radius = token.getRadius();
            return ((center.x + radius) <= (launchArea.x + 100))
                    && ((center.x - radius) >= (launchArea.x - 100))
                    && ((center.y + radius) <= (launchArea.y + 100))
                    && ((center.y - radius) >= (launchArea.y - 100));
        }
        else return false;
    }
    
    // Score Live
    public void winnerLive() {
        if (centers.isEmpty()) {
            throw new IllegalStateException("Normalement impossible de voir ce message");
        }
        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < centers.size(); i++) {
            indices.add(i);
        }
        indices.sort((i1, i2) -> Double.compare(
            dist(centers.get(i1), target), 
            dist(centers.get(i2), target)
        ));
        int c = 1; 
        boolean currentTeam = teamid.get(indices.get(0)); 
        
        for (int i = 1; i < indices.size(); i++) {
            if (teamid.get(indices.get(i)) == currentTeam) {
                c++;
            } else {
                break;
            }
        }
        avLive = currentTeam ? c : -c; 
    }
    // FIN EN PLUS
    /*
    public void update() {
        if (turnCounts == 16) {
            turnCounts = 0;
            if (getWinner()) {
                scoreGameRED++;
                
            } else {
                scoreGameBLUE++;
            }
            centers.clear();
            radius.clear();
            teamid.clear();
            //turnsRemainingRED = 8;
            //turnsRemainingBLUE = 8;

            if (onScoreUpdate != null) {
                onScoreUpdate.run(); // Notify score update
            }
        }
    } */
    
    // EN PLUS
    public void update() {
        if (turnCounts == 16) {
            turnCounts = 0;
            if(avLive < 0) {
                    scoreGameRED -= avLive;
            } else {
                    scoreGameBLUE += avLive;
            }
            avLive = 0 ;    
            centers.clear();
            radius.clear();
            teamid.clear();
            if (onScoreUpdate != null) {
            onScoreUpdate.run(); // Notify score update
            }
        }
    }
    // FIN EN PLUS
    
    public List<Point> getCenters() {
        return new ArrayList<>(centers);
    }

    public List<Integer> getRadius() {
        return new ArrayList<>(radius);
    }

    public List<Boolean> getTeamid() {
        return new ArrayList<>(teamid);
    }

    public void setTarget(Point target) {
        this.target = target;
    }

    public Point getTarget() {
        return target;
    }
    
    public String getCurrentTeam() {
        return (turnCounts % 2 == 0) ? "Blue Team" : "Red Team";
    }
    public int getTurnCounts() {
        return turnCounts;
    }
    
    public void setLaunchArea(Point launchArea) {
        this.launchArea = launchArea;
    }

    public Point getLaunchArea() {
        return launchArea;
    }
}
