package fise2.image4.projetinfo;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

public class TokenDetector {
	public Mat detectTokens(Mat frame) {
       
        Mat hsvFrame = new Mat();
        Imgproc.cvtColor(frame, hsvFrame, Imgproc.COLOR_BGR2HSV);

       
        Scalar lowerColor = new Scalar(0, 100, 100);
        Scalar upperColor = new Scalar(10, 255, 255);

        Mat mask = new Mat();
        Core.inRange(hsvFrame, lowerColor, upperColor, mask);
        return mask;
    }
}
