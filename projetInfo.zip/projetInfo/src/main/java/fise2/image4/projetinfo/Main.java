 
package fise2.image4.projetinfo;
/*
import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.highgui.HighGui;
import org.opencv.videoio.VideoCapture;

public class Main {
    private VideoCapture capture;
    private GameManager gameEngine;
    private TokenDetectorbis tkd;
    // EN PLUS
    private List<Point> centers;
    private boolean state;
    // FIN EN PLUS
    

    public Main() {
        System.load("C:/Users/KazuWaii/eclipse-workspace/image4_project/src/main/resources/libs/opencv_java4100.dll");
        capture = new VideoCapture(0);
        // EN PLUS
        centers = new ArrayList<Point>();
        state = true; 
        // FIN EN PLUS
        if (capture.isOpened()) {
            Mat frame = captureFrame();
            if (!frame.empty()) {
                gameEngine = new GameManager(new Point(200, 200), new Point(500,300));
                Mat background = frame.clone();
                tkd = new TokenDetectorbis(background, List.of(0, 40));
            } else {
                System.out.println("Error: Unable to initialize background.");
            }
        }
    }

    public Mat captureFrame() {
        Mat frame = new Mat();
        if (capture.isOpened()) {
            capture.read(frame);
        }
        return frame;
    }
    
    // EN PLUS
    private Double dist(Point A, Point B){
    	
    	return Math.sqrt(Math.pow(A.x - B.x, 2) + Math.pow(A.y - B.y, 2));
    }
    
    public boolean isStable(List<Point> rayons, double threshold) {
        if (rayons.size() < 20) {
            return false; 
        }
        
        double sum = 0.0;
        for (int i = rayons.size() - 20; i < rayons.size() - 1; i++) {
            double distance = dist(rayons.get(i), rayons.get(i + 1));
            if (distance > threshold) {
                return false; 
            }
            sum += distance;
        }
        
        double normalizedSum = sum / 20.0;
        return normalizedSum < threshold;
    }
    // FIN EN PLUS
    /*
    public void start() {
        if (!capture.isOpened()) {
            System.out.println("Error: Could not open video stream.");
            return;
        }

        Mat frame = new Mat();
        int key = -1;

        while (true) {
            if (!capture.read(frame)) {
                System.out.println("Error: Could not read frame from stream.");
                break;
            }

            Mat displayFrame = frame.clone();
            tkd.displayCircles(displayFrame, gameEngine.getCenters(), gameEngine.getRadius(), gameEngine.getTeamid());
            tkd.displayHud(displayFrame, gameEngine.scoreGameBLUE, gameEngine.scoreGameRED);
            tkd.displayTarget(displayFrame, gameEngine.getTarget());

            HighGui.imshow("Webcam Stream", displayFrame);

            key = HighGui.waitKey(10);

            if (key != -1) {
                char pressedKey = (char) key;
                System.out.println("Key pressed: " + pressedKey);

                if (pressedKey == 'F' || pressedKey == 'f') {
                    tkd.setBackground(frame.clone());
                }

                if (pressedKey == 'T' || pressedKey == 't') {
                    Circle circle = tkd.detectToken(frame);
                    if (circle != null) {
                        gameEngine.addCircle(circle.getCenter(), circle.getRadius());
                    }
                }

                if (pressedKey == 'Q' || pressedKey == 'q') {
                    break;
                }
            }

            gameEngine.update();
        }

        releaseResources();
    }
    */

  /*  
    // EN PLUS
    public void start() throws InterruptedException {
        // Erreur si la caméra n'est pas trouvée
        if (!capture.isOpened()) {
            System.out.println("Error: Could not open video stream.");
            return;
        }

        Mat frame = new Mat();
        
        //Calibrage !!marche pas!!
        /*if (!updateFrame(frame)) {
                System.out.println("Error: Could not read frame from stream.");
            }
        
        Circle circle = tkd.detectToken(frame);
        System.out.println("STARTING CALIBRATION, PLEASE PLACE TOKEN IN LAUNCH AREA");
        while(true){
            if (gameEngine.isCircleInLaunchArea(circle)){
                tkd.fixRadius(frame.clone());
                System.out.println("CALIBRATION SUCCESSFULL");
                break;
            }
            
            if (!updateFrame(frame)) {
                System.out.println("Error: Could not read frame from stream.");
            }
            
            circle = tkd.detectToken(frame);
        }*/
   

/*
        while (true) {
            //Gestion du jeu sans touches
            if (!updateFrame(frame)) {
                System.out.println("Error: Could not read frame from stream.");
                break;
            }
            
           Circle circle = tkd.detectToken(frame);
            while (!gameEngine.isCircleInLaunchArea(circle)) {
                if (!updateFrame(frame)) {
                    System.out.println("Error: Could not read frame from stream.");
                    break;
                }
                
                circle = tkd.detectToken(frame);
            }
            System.out.println("IN LAUNCH AREA");
            
            while (gameEngine.isCircleInLaunchArea(circle)) {
                                
                if (!updateFrame(frame)) {
                    System.out.println("Error: Could not read frame from stream.");
                    break;
                }
                
                circle = tkd.detectToken(frame);
            }
            
            long startTime = System.currentTimeMillis();
            
            while (System.currentTimeMillis()-startTime < 1000){
                if (!updateFrame(frame)) {
                    System.out.println("Error: Could not read frame from stream.");
                    break;
                }
            }
            
            circle = tkd.detectToken(frame);
            
            if (!gameEngine.isCircleInLaunchArea(circle)){
                gameEngine.addCircle(circle.getCenter(), circle.getRadius());
                centers.clear();
                System.out.println("LAUNCHED");
            }
            

            // Tour
            gameEngine.update();
        }

        releaseResources();
    }
    
    private boolean updateFrame(Mat frame){
        
        if (!capture.read(frame)) {
                    System.out.println("Error: Could not read frame from stream.");
                    return false;
        }
        
        Mat displayFrame = frame.clone();
                
        tkd.displayCircles(displayFrame, gameEngine.getCenters(), gameEngine.getRadius(), gameEngine.getTeamid());
        tkd.displayHud(displayFrame, gameEngine.scoreGameBLUE, gameEngine.scoreGameRED, gameEngine.avLive);
        tkd.displayTarget(displayFrame, gameEngine.getTarget());
        tkd.displayLaunchArea(displayFrame, gameEngine.getLaunchArea());
                
        HighGui.imshow("Webcam Stream", displayFrame);
        int key = HighGui.waitKey(10);
        
        return true;
    }
    // FIN EN PLUS

    private void releaseResources() {
        capture.release();
        HighGui.destroyAllWindows();
    }

    public static void main(String[] args) throws InterruptedException {
    	Main app = new Main();
        app.start();
    }
}
*/