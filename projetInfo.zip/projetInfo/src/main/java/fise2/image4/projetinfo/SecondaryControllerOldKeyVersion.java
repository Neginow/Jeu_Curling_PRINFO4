package fise2.image4.projetinfo;

import java.io.IOException;
import static java.lang.Integer.max;
import java.util.ArrayList;
import javafx.util.Duration;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.shape.Rectangle;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.image.WritableImage;
import javafx.scene.text.Text;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.highgui.HighGui;
import org.opencv.videoio.VideoCapture;

public class SecondaryControllerOldKeyVersion {

    @FXML
    private ImageView cameraView;
    @FXML
    private Label redScoreLabel;
    @FXML
    private Label blueScoreLabel;
    @FXML
    private Label teamTurnLabel;
    @FXML
    private Label elapsedTimeLabel;
    @FXML
    private Label redTurnsLabel;
    @FXML
    private Label blueTurnsLabel;
    @FXML 
    private Button pauseButton;
    @FXML
    private Rectangle dimOverlay;
    @FXML
    private Text gamePausedLabel;


    private Timeline elapsedTimeTimeline;
    private int elapsedSeconds;
    private boolean isPaused = false;


    private VideoCapture capture;
    private Timer frameTimer;
    private GameManager gameEngine;
    private TokenDetectorbis tkd;
    
    // EN PLUS
    private List<Point> centers;
    private boolean state;
    // FIN EN PLUS

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary");
    }

    public void initialize() {
        // Load OpenCV native library
        System.load("C:/Users/KazuWaii/eclipse-workspace/image4_project/src/main/resources/libs/opencv_java4100.dll");

        // Initialize the video capture
        capture = new VideoCapture(0);
        // EN PLUS
        centers = new ArrayList<Point>();
        state = true; 
        // FIN EN PLUS

        if (!capture.isOpened()) {
            System.out.println("Error: Unable to open video stream.");
            return;
        }

        // Initialize game manager and token detector
        Mat frame = captureFrame();
        if (!frame.empty()) {
            gameEngine = new GameManager(new Point(500,300), frame); // EN PLUS
            Mat background = frame.clone();
            tkd = new TokenDetectorbis(background, List.of(0, 40));
        } else {
            System.out.println("Error: Unable to initialize background.");
            return;
        }

        startElapsedTime(); // Start tracking elapsed time
        
        // Start frame update timer
        startFrameTimer();
        applyRoundedCornersToCameraView();

        // Attach the key event listener to the scene of the root node
        Platform.runLater(() -> {
            // Make sure the scene is set before attaching the key listener
            if (cameraView.getScene() != null) {
                cameraView.getScene().setOnKeyPressed(this::handleKeyPress);
            } else {
                System.out.println("Scene is not yet set.");
            }
        });
        
        gameEngine.setOnScoreUpdate(() -> Platform.runLater(this::updateScoresUI));
    }
    
    // EN PLUS
    private Double dist(Point A, Point B){
    	
    	return Math.sqrt(Math.pow(A.x - B.x, 2) + Math.pow(A.y - B.y, 2));
    }
    
    public boolean isStable(List<Point> rayons, double threshold) {
        if (rayons.size() < 20) {
            return false; 
        }
        
        double sum = 0.0;
        for (int i = rayons.size() - 20; i < rayons.size() - 1; i++) {
            double distance = dist(rayons.get(i), rayons.get(i + 1));
            if (distance > threshold) {
                return false; 
            }
            sum += distance;
        }
        
        double normalizedSum = sum / 20.0;
        return normalizedSum < threshold;
    }
    // FIN EN PLUS
    
    public void updateUI() {
        // Update the UI with the remaining turns for each team
        redTurnsLabel.setText(String.valueOf(gameEngine.getTurnsRemainingRED()));
        blueTurnsLabel.setText(String.valueOf(gameEngine.getTurnsRemainingBLUE()));
    }
    
    public void handleTurnMade(boolean isRedTeam) {
        // Example: if it's red team's turn
        gameEngine.setTurnsRemaining(isRedTeam);  // Red team turn
        updateUI();  // Refresh the UI to show the updated remaining turns
    }
    
    private void startElapsedTime() {
        elapsedSeconds = 0;

        // Create a Timeline to update the elapsed time every second
        elapsedTimeTimeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            elapsedSeconds++;
            updateElapsedTimeLabel();
        }));

        elapsedTimeTimeline.setCycleCount(Timeline.INDEFINITE); // Run indefinitely
        elapsedTimeTimeline.play();
    }

    private void updateElapsedTimeLabel() {
        int minutes = elapsedSeconds / 60;
        int seconds = elapsedSeconds % 60;
        elapsedTimeLabel.setText(String.format("%02d:%02d", minutes, seconds));
    }

    public void resetElapsedTime() {
        elapsedTimeTimeline.stop();
        elapsedSeconds = 0;
        updateElapsedTimeLabel();
        elapsedTimeTimeline.play();
    }

    public void pauseElapsedTime() {
        elapsedTimeTimeline.pause();
    }

    public void resumeElapsedTime() {
        elapsedTimeTimeline.play();
    }
    
    
    private Mat captureFrame() {
        Mat frame = new Mat();
        if (capture.isOpened()) {
            capture.read(frame);
        }
        return frame;
    }

    private void startFrameTimer() {
        frameTimer = new Timer(true);
        frameTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Mat frame = captureFrame();
                if (!frame.empty()) {
                    Mat displayFrame = frame.clone();
                    
                    // Overlay game elements
                    tkd.displayCircles(displayFrame, gameEngine.getCenters(), gameEngine.getRadius(), gameEngine.getTeamid());
                    //tkd.displayHud(displayFrame, gameEngine.scoreGameBLUE, gameEngine.scoreGameRED);
                    tkd.displayTarget(displayFrame, gameEngine.getTarget());

                    // Convert Mat to WritableImage
                    WritableImage writableImage = OpenCVUtils.matToImage(displayFrame);

                    // Update the ImageView on the JavaFX Application Thread
                    Platform.runLater(() -> {
                        cameraView.setImage(writableImage);
                        cameraView.setImage(writableImage);
                        updateTurnUI();  // Update current team
                        
                        updateScoresUI(); // Update UI safely
                        resetTurnsRemaining();
                        updateUI();
                    });                    
                    // Update game logic
                    gameEngine.update();                    
                }
            }
        }, 0, 33); // ~30 FPS
    }
    
    private void resetTurnsRemaining(){
        if (gameEngine.getTurnCounts() == 16 || gameEngine.getTurnCounts() == 0) {
            gameEngine.setTurnsRemainingRED(8);
            gameEngine.setTurnsRemainingBLUE(8);
       }
    }
    
    private void updateScoresUI() {
        redScoreLabel.setText(String.valueOf(gameEngine.scoreGameRED));
        blueScoreLabel.setText(String.valueOf(gameEngine.scoreGameBLUE));
    }
    private void updateTurnUI() {
        String currentTeam = gameEngine.getCurrentTeam();
        teamTurnLabel.setText(currentTeam);

        // Change the label color based on the team
        if (currentTeam.equals("Red Team")) {
            teamTurnLabel.setStyle("-fx-text-fill: #ff0000; -fx-font-size: 30px; -fx-font-family: 'Immortal', sans-serif;");
        } else if (currentTeam.equals("Blue Team")) {
            teamTurnLabel.setStyle("-fx-text-fill: #0006ff; -fx-font-size: 30px; -fx-font-family: 'Immortal', sans-serif;");
        }
    }

    

    // Handle key presses
    private void handleKeyPress(KeyEvent event) {
        char pressedKey = event.getText().toLowerCase().charAt(0);

        System.out.println("Key pressed: " + pressedKey);

        switch (pressedKey) {
            case 'f':
                // Set background
                Mat frame = captureFrame();
                tkd.setBackground(frame.clone());
                break;
            case 't':
                // Detect token
                Mat frameForToken = captureFrame();
                Circle circle = tkd.detectToken(frameForToken);
                if (circle != null) {
                    if (gameEngine.getCurrentTeam().equals("Red Team")) handleTurnMade(true);
                    else handleTurnMade(false);
                    gameEngine.addCircle(circle.getCenter(), circle.getRadius());
                }
                break;
            case 'p':
                // Pause/Resume game
                togglePause();
                break;
            case 'q':
                // Quit the application
                stopCamera();
                Platform.exit();
                break;
            default:
                break;
        }
    }
    
    @FXML
    private void togglePause() {
        if (isPaused) {
            resumeGame();
        } else {
            pauseGame();
        }
        isPaused = !isPaused;
    }
    
    private void pauseGame() {
        // Stop timers
        pauseElapsedTime();
        if (frameTimer != null) {
            frameTimer.cancel();
        }

        // Disable all interactions except for the 'p' key
        cameraView.setDisable(true);
        Platform.runLater(() -> {
            if (cameraView.getScene() != null) {
                cameraView.getScene().setOnKeyPressed(event -> {
                    if ("p".equalsIgnoreCase(event.getText())) {
                        togglePause(); // Allow toggling pause using 'p'
                    }
                });
            }
        });
        pauseButton.setStyle("-fx-background-color: #FF5555; -fx-background-radius: 155; -fx-font-family:  'Immortal', sans-serif; -fx-font-size: 20");
        // Show dim overlay to darken other UI elements
        dimOverlay.setVisible(true);
        gamePausedLabel.setVisible(true);
        // Show a "Paused" overlay (optional)
        //pausedLabel.setVisible(true); // Assuming you have a paused label

        System.out.println("Game paused.");
    }

    
    private void resumeGame() {
        // Restart timers
        resumeElapsedTime();
        startFrameTimer();

        // Re-enable interactions
        cameraView.setDisable(false);
        Platform.runLater(() -> {
            if (cameraView.getScene() != null) {
                cameraView.getScene().setOnKeyPressed(this::handleKeyPress); // Reattach key listener
            }
        });
        pauseButton.setStyle("-fx-background-color: #6fdbff; -fx-background-radius: 155; -fx-font-family:  'Immortal', sans-serif; -fx-font-size: 20");
        // Show dim overlay to darken other UI elements
        dimOverlay.setVisible(false);
        gamePausedLabel.setVisible(false);
        // Hide the "Paused" overlay (optional)
        //pausedLabel.setVisible(false);

        System.out.println("Game resumed.");
    }

    
    public void stopCamera() {
        if (frameTimer != null) {
            frameTimer.cancel();
        }
        if (capture != null) {
            capture.release();
        }
    }
    
    private void applyRoundedCornersToCameraView() {
        // Define the width, height, and corner radius
        double cornerRadius = 20; // Adjust the radius as needed
        double width = cameraView.getFitWidth();
        double height = cameraView.getFitHeight();

        // Create a Rectangle to clip the ImageView with rounded corners
        Rectangle clip = new Rectangle(0, 0, width, height);
        clip.setArcWidth(cornerRadius);
        clip.setArcHeight(cornerRadius);

        // Clip the cameraView with the rectangle
        cameraView.setClip(clip);

        // Optional: Set the width and height of the ImageView (you can adjust this)
        cameraView.setFitWidth(width);
        cameraView.setFitHeight(height);
    }
}
